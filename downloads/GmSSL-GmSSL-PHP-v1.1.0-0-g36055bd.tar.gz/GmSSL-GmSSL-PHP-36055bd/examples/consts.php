<?php
print("GmSSL PHP Version: ".GMSSL_PHP_VERSION."\n");
print("GmSSL Library Version: ".GMSSL_LIBRARY_VERSION."\n");
?>
