<?php
/**
 * @generate-function-entries
 */
function swoole_get_objects(): false|array
{
}

function swoole_get_vm_status(): array
{
}

function swoole_get_object_by_handle(int $handle): false|object
{
}

function swoole_name_resolver_lookup(string $name, Swoole\NameResolver\Context $ctx) : string
{
}

function swoole_name_resolver_add(Swoole\NameResolver $ns) : bool
{
}

function swoole_name_resolver_remove(Swoole\NameResolver $ns) : bool
{
}
