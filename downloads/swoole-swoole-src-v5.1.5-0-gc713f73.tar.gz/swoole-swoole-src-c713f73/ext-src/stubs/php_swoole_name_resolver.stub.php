<?php
/**
 * @generate-function-entries
 */
namespace Swoole\NameResolver {
    class Context {
        public function __construct(int $family = AF_INET, bool $withPort = false) {}
    }
}
