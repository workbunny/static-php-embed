# gRPC C++ Multiplexing Example

This example shows how to use a single connection to send multiple concurrent
asynchronous requests to different services. It also demonstrates multiple
sharing the same server connection.

[C++ Quick Start]: https://grpc.io/docs/languages/cpp/quickstart
